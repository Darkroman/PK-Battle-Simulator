#pragma once

#include <string_view>

enum class SetPokemonResult {
    Success,
    InvalidRange,
    InvalidPokemon,
    InvalidSlot,
    Exit
};

enum class SetMoveResult {
    Success,
    InvalidSlot,
    InvalidRange,
    InvalidMove,
    NotLearnable,
    DuplicateMove,
    Exit
};

enum class SetLevelResult {
    Success,
    InvalidLevel
};

enum class SetIVResult {
    Success,
    InvalidValue,
};

enum class SetEVResult {
    Success,
    InvalidValue,
    ExceedsTotal
};

struct SetPokemonOutcome
{
    SetPokemonResult result{};
    std::string_view pokemonName{};
};

struct SetMoveOutcome
{
    SetMoveResult result{};
    std::string_view moveName{};
};